#include <SFML/System.hpp>
#include <SFML/Window.hpp>

#include "Game.h"

int main()
{
    Game g;
    g.Run();

    return 0;
}
