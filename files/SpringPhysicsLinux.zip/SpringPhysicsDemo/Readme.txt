To run this you need LWJGL and OpenGL installed and someone in your PATH environment variable.

Controls
A -> Rotate counter-clockwise
D -> Rotate clockwise
Shift -> Weaken springs
Space -> Stiffen springs
