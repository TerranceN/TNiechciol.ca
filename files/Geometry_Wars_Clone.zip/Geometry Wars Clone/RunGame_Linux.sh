#!/bin/bash
java -jar -Djava.library.path=linux/ GW.jar
