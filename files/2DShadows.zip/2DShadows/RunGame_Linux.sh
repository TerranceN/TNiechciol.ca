#!/bin/bash
java -jar -Djava.library.path=linux/ Game.jar
