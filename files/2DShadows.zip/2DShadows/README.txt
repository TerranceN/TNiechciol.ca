2D Dynamic Hard Shadows Using FBOs
----------------------------------
Created by Terrance Niechciol

Controls
-------

WASD ---------------- Movement
QE ------------------ Rotate camera
T ------------------- Toggle flashlight
Right Mouse --------- Add light source
C ------------------- Remove all added light sources

Editor Controls
---------------
1 ------------------- Select Mode
2 ------------------- Move Mode
Z ------------------- Zoom Extents
Scroll-Wheel -------- Zoom

In Select Mode
--------------
Left-Click ----------- Select shape
Control-Left-Click --- Add shape to selection

In Move Mode
--------------
Left-Click-Drag ------ Move selected shapes
