Spring Physics Demo
-------------------

Created by
----------
Terrance Niechciol
TNiechciol@gmail.com
www.student.cs.uwaterloo.ca/~tniechci/

Controls
--------
A       -> Rotate counter-clockwise
D       -> Rotate clockwise
Shift   -> Weaken springs
Space   -> Stiffen springs
